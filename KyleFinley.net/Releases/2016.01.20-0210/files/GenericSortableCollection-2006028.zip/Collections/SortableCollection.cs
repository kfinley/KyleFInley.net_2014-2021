using System;

/// <summary>
/// An example of a typed collection using Generics.  This collection class also provides a feature for sorting
/// objects within the collection.  Sorting is performed using a comparable object.
/// </summary>
public class SortableCollection<T> : System.Collections.CollectionBase
{
    #region Public Properties

    /// <summary>
    /// Gets or sets the item at a given index in the Collection
    /// </summary>
    public virtual T this[int index]
    {
        get
        {
            return (T)this.List[index];
        }
        set
        {
            this.List[index] = value;
        }
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Returns the index of the given item.
    /// </summary>
    /// <param name="item">Item to lookup.</param>
    /// <returns>Index value of the item in the collection</returns>
    public virtual int IndexOf(T item)
    {
        return this.List.IndexOf(item);
    }

    /// <summary>
    /// Adds an item to the collection.
    /// </summary>
    /// <param name="item">Item to add.</param>
    /// <returns>Index value of location of newly added item.</returns>
    public virtual int Add(T item)
    {
        return this.List.Add(item);
    }

    /// <summary>
    /// Removes an item from the collection.
    /// </summary>
    /// <param name="item">Item to remove.</param>
    public virtual void Remove(T item)
    {
        this.List.Remove(item);
    }

    /// <summary>
    /// Copies the contents of the collection to a given array, starting at a given location.
    /// </summary>
    /// <param name="array">Array to copy items to.</param>
    /// <param name="index">Index location to start copying from.</param>
    public virtual void CopyTo(Array array, int index)
    {
        this.List.CopyTo(array, index);
    }

    /// <summary>
    /// Adds a Collection of items to a collection.
    /// </summary>
    /// <param name="collection">Collection of items to add.</param>
    public virtual void AddRange(SortableCollection<T> collection)
    {
        this.InnerList.AddRange(collection);
    }

    /// <summary>
    /// Adds an array of items to a collection
    /// </summary>
    /// <param name="collection">Array of items to add.</param>
    public virtual void AddRange(T[] collection)
    {
        this.InnerList.AddRange(collection);
    }

    /// <summary>
    /// Checks to see if the Collection contains a specific item.
    /// </summary>
    /// <param name="item">Item to check for.</param>
    /// <returns>Boolean value representing if the item is present or not.</returns>
    public virtual bool Contains(T item)
    {
        return this.List.Contains(item);
    }

    /// <summary>
    /// Inserts an item into the collection at a given location.
    /// </summary>
    /// <param name="index">Index of the location to insert the item in the collection.</param>
    /// <param name="item">Item to insert.</param>
    public virtual void Insert(int index, T item)
    {
        this.List.Insert(index, item);
    }

    /// <summary>
    /// Sorts the collection based on a Property Name provided and a SortDirection.
    /// </summary>
    /// <param name="sortPropertyName">The property name on which to sort the collection.</param>
    /// <param name="sortDirection">Direction in which to sort the collection.</param>
    public void Sort(string sortExpression, SortDirection sortDirection)
    {
        InnerList.Sort(new Comparer(sortExpression, sortDirection));
    }

    /// <summary>
    /// Sorts the collection based on a Property Name provided. Default sort order is Ascending.
    /// </summary>
    /// <param name="sortExpression">The proprety on which to sort the collection.</param>
    public void Sort(string sortExpression)
    {
        InnerList.Sort(new Comparer(sortExpression));
    }

    #endregion
}

    