using System ;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for Employee
/// </summary>
public class Employee
{

    private string m_FirstName, m_LastName ;
    private int m_ID ;
    private DateTime m_HireDate ;
    private string m_Title ;
    private string m_Gender ;

    public Employee()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    
    public int ID
    {
        get { return m_ID; }
        set { m_ID = value; }
    }
    public string FirstName
    {
        get { return m_FirstName; }
        set { m_FirstName = value; }
    }
    public string LastName
    {
        get { return m_LastName; }
        set { m_LastName = value; }
    }
    public string Title
    {
        get { return m_Title; }
        set { m_Title = value; }
    }
    public string Gender
    {
        get { return m_Gender; }
        set { m_Gender = value; }
    }
    public DateTime HireDate
    {
        get { return m_HireDate; }
        set { m_HireDate = value; }
    }
}
