﻿using System.ComponentModel;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using Finley.Common;

namespace Finley.Common.Tests
{
    
    /// <summary>
    ///This is a test class for TypeMergerTest and is intended
    ///to contain all TypeMergerTest Unit Tests
    ///</summary>
    [TestClass()]
    public class TypeMergerTest
    {


        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        private class TestObject
        {
            public bool Success { get; set; }
            public string Message { get; set; }
            public object BigHeavyObject { get; set; }
        }


        /// <summary>
        /// Merge an instance of a concrete class with an anonymous type resulting in a new anonymous type containing values from both.
        /// </summary>
        /// <remarks>
        /// - Desired Result:	Create a merged Anonymous Type
        /// - Coordinator:      Using TypeMerger
        /// - Conditions:       Given a concrete class instance and an Anonymous Type
        /// </remarks>
        [TestMethod]
        public void Create_a_merged_Anonymous_Type_Using_TypeMerger_Given_a_concrete_class_instance_and_an_Anonymous_Type()
        {
            // Arrange
            TestObject values1 = new TestObject { Success = true, Message = "It worked!", BigHeavyObject = new object() };
            var values2 = new { MoreInfo = "Extra stuff" };
            var expected = new { Success = true, Message = "It worked!", MoreInfo = "Extra stuff" };

            // Act
            var result = TypeMerger.Ignore(values1.BigHeavyObject).MergeTypes(values1, values2);

            // Grab the properties for our new Anonymous Type
            PropertyDescriptorCollection pdc = TypeDescriptor.GetProperties(result);
            
            // Assert
            Assert.IsTrue(pdc.Count == 3);

            Assert.AreEqual((bool)pdc["Success"].GetValue(result), true);
            Assert.AreEqual((string)pdc["Message"].GetValue(result), "It worked!");
            Assert.AreEqual((string)pdc["MoreInfo"].GetValue(result), "Extra stuff");
        }
    }
}
